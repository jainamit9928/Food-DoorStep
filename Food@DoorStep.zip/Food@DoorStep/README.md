# FOOD@DOORSTEP APP

STEPS  TO START

1) NPM INSTALL
2) NPM START
3) Production : npm build:prod

Description:
This named FOOD@DOORSTEP App can be used for ordering food and shipping process for any eCommerce.
It contains 2 pages 
Login:Used For Authentication
Please use below credentials
username:demoaccount
password:Passw0rd
HOME: contains gallery and features fod
Menu: containing resturant menu and can order food
ShippingDetails:For shipping 

NOTE: i have used browser localstorage for ordering the food