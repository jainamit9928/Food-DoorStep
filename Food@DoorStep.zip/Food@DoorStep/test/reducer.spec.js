import React from 'react';
import * as types from '../src/js/constants/constants';
import { shippingDetail } from '../src/js/reducers/reducer.js';


describe('shippingDetails reducer', () => {
    
        it('Set Shipping Detail', () => {
        expect(shippingDetail(undefined, { type:types.SET_SHIPPING_DETAIL , data:{} })).toEqual( {
         steps:1,
        detail:{ receiverDetails:{name:"", street:"", city:"", state:"" }, senderDetails:{ name:"", street:"", city:"", state:"" }, productDetails:{items:[] ,shippingOption:{ ground:1, priority:2 }}, totalCost:null }
        })
       }),
         it('set Steps', () => {
        expect(shippingDetail(undefined, { type:types.SET_STEPS,data:2 })).toEqual( {
          steps:2,
         detail:{ receiverDetails:{name:"", street:"", city:"", state:"" }, senderDetails:{ name:"", street:"", city:"", state:"" }, productDetails:{items:[] ,shippingOption:{ ground:1, priority:2 }}, totalCost:null }
        })
       })

})
