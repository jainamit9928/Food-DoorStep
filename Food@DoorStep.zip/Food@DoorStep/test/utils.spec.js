import React from 'react';
import { calculateCost } from '../src/js/utils/utils';


describe('calculate cost', () => {
    
        it('shoudl calculate total cost', () => {
        expect(calculateCost({items:[] , shippingOption:{ground:1,priority:1}},0)).toEqual(0)
       })

})