import * as types from '../constants/constants.js'

export const setShippingDetail = (data) => ({ type: types.SET_SHIPPING_DETAIL, data })
export const setSteps = (data) => ({ type: types.SET_STEPS, data })
export const getDataSuccess = (data) => ({ type: types.GET_DATA_SUCCESS, data })
export const getDataFailure = (message) => ({ type: types.GET_DATA_FAILURE, message })
export const getDataRequest = () => ({ type: types.GET_DATA_REQUEST })
export const updateDataSuccess = (data) => ({ type: types.UPDATE_DATA_SUCCESS, data })
export const updatDataFailure = (message) => ({ type: types.UPDATE_DATA_FAILURE, message })
export const updatDataRequest = (id, updatedObj) => ({ type: types.UPDATE_DATA_REQUEST, id, updatedObj })

