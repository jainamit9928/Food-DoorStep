import React from 'react'
import Modal from '../core/modal'
import Login from '../core/login'
import { LOGIN_HEADER } from '../../constants/constants'
import _ from 'lodash'
import { Gallery } from '../core/gallery'
import { WelcomeLogo  } from '../core/welcomelogo'

export default class Home extends React.PureComponent {

    constructor(props) {
        super(props);
        this.state = {
            isModalOpen: true,
            hasError: false
        }
        this.onOpenModal = this.onOpenModal.bind(this)
        this.onCloseModal = this.onCloseModal.bind(this)

    }
    componentDidMount() {
        const status = JSON.parse(window.localStorage.getItem('status'))
        if (status == "login successfully") {
            this.setState({ isModalOpen: false })
        }
        this.props.actions.getDataRequest();

    }
    onOpenModal() {
        this.setState({ isModalOpen: true })
    }
    onCloseModal() {
        this.setState({ isModalOpen: false })
        this.props.history.push('/');
    }

    render() {
        console.log("home",this.props.items)
        let features = _.filter(this.props.items, (item) => (item.type === "features"))
        return (
            <div>
                <Modal header={LOGIN_HEADER} isOpen={this.state.isModalOpen} >
                    <Login onClose={this.onCloseModal} />
                </Modal>
               { !(this.state.isModalOpen) && (
                   <div>
                   <WelcomeLogo /> 
                   <Gallery />
                   <section className="featured_dishes">
		            <div className="wrapper">
                    <section className="info">
				<div className="title">
					<h3>Featured Dishes</h3>
					<span className="separator"></span>
				</div>
				<div className="slider_nav" id="slider_nav">
				</div>
			</section>
            <section className="dishes" id="dishes">
{
            _.map(features, (itm) => (
                <Features key={itm.id} item={itm} />
            ))
}
                </section>
                    </div>
	                </section>
                    </div>
               )}
               
                }

            </div>
        )
    }
}

const Features = (item) =>{
console.log("item is",item)
return (

    <article>
					<div className="dishe_img">
						<a href="#"><img src={ item.item.avatar } alt="" title=""/></a>					
					</div>
					<div className="dish_info">
						<a href="#"><h2>{ item.item.item_name }</h2></a>
						<h3>{ item.item_price }</h3>
					</div>
					<ul className="rating">
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li className="no-star"></li>
					</ul>
				</article>
)
}
