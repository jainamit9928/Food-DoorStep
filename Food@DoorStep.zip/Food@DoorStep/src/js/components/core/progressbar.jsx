import React from 'react';
import {render} from 'react-dom';
import {BrowserRouter as Router, Route, Link} from "react-router-dom";

class ProgressBar extends React.Component {
    constructor(props){
        super(props);
        this.state= {
            steps : ['Your Address','Alternate Address','Product Details','Confirmation']
        }
    }

    render() {

        return (
            <div className="btn-group progress-bar">
                {this.state.steps.map((value,index) => <Steps value={value} className="btn btn-default progress-steps" index={index} key={index} counter={this.props.progressSteps}/>)}

            </div>
        );
    }
}


class Steps extends React.Component {
    constructor(props){
        super(props);
        console.log('give steps',this.props.counter);
        this.state = {
            stepClass : {
                    backgroundColor : '#31798f',
                    borderRadius : '5px',
                    padding : '1em',
                    border: 0,
                    width : '10%',
                    display : 'inline-block',
                    color: 'black',
                    borderTop: '20px solid transparent',
                    borderRight: '20px solid transparent',
                    borderBottom: '20px solid transparent',
                    borderLeft: '20px solid #fff',

                }
        }
    }
    componentWillMount(){
        if(this.props.index==0){
            this.setState({stepClass : Object.assign({}, this.state.stepClass, { backgroundColor: '#8bc435' })});
        }

    }
    componentWillReceiveProps(nextProps){
        if (nextProps.index === (nextProps.counter -1)){
            this.setState({stepClass : Object.assign({}, this.state.stepClass, { backgroundColor: '#8bc435'})});
        }
        else{
            this.setState({stepClass : Object.assign({}, this.state.stepClass, { backgroundColor: '#31798f' })});
        }
    }
    render() {

        return (

            <div style={this.state.stepClass} className="details">
                <span >{this.props.value}</span>
            </div>
        );
    }
}

export default ProgressBar;
