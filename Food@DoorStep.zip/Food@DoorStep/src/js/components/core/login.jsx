import React from 'react'
import ErrorComponent from './showerror'

class Login extends React.PureComponent {
    constructor(props){
        super(props);
        this.onAuthorize = this.onAuthorize.bind(this);
         this.state = {
            hasError:false
        }
    }

    onAuthorize(e){
        e.preventDefault();
        const user = JSON.parse(window.localStorage.getItem('username'))
        const password = JSON.parse(window.localStorage.getItem('password'))
        if(this.username.value === user && this.password.value === password ){
            this.props.onClose()
            this.setState({hasError:false})
            window.localStorage.setItem('status', JSON.stringify("login successfully"))
        }
        else{
           this.setState({hasError:true})
        }
        console.log('username',);
    }

    render(){
        return (
            <div>
             <ErrorComponent className='error' noDataFound ={ this.state.hasError } />
            <div className="login">
                <form className="form-horizontal">
                    <label ></label>
                    <input type="text" name="" id="" placeholder="username"  className="user" ref={(input) => { this.username = input; }} ></input>

                    <label ></label>
                    <input type="password" name="" id="" placeholder="password" className="pass" ref={(input) => { this.password = input; }} ></input>
                    <button type="submit" onClick={this.onAuthorize}>login</button>
                </form>
            </div>
            </div>
        )
    }

}

export default Login;
