import React from 'react'
import { API_URL } from '../../constants/constants'

export const Gallery = () => (
	<section className="gallery">
		<div className="wrapper">
			<section className="info">
				<div className="title">
					<h3>The Gallery</h3>
					<span className="separator"></span>
				</div>
			</section>

			<div className="media">
				<section>
					<a href="#">
						<img src= { API_URL + "/img1.jpg" } alt="" title=""/>
					</a>
				</section>

				<section>
					<div className="hhalf">
						<a href="#">
							<img src= { API_URL + "/img2.jpg" } alt="" title=""/>
						</a>
					</div>
					<div className="hhalf">
						<a href="#">
							<img src= { API_URL + "/img3.jpg" }  alt="" title=""/>
						</a>
					</div>
				</section>

				<section>
					<div className="hhalf">
						<a href="#">
							<img src= { API_URL + "/img4.jpg" } alt="" title=""/>
						</a>
					</div>
					<div className="hhalf">
						<a href="#">
							<img src= { API_URL + "/img5.jpg" }   alt="" title=""/>
						</a>
					</div>
				</section>
			</div>
		</div>
	</section>

)