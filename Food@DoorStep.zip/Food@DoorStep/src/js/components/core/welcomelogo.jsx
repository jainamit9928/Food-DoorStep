import React from 'react'

export const WelcomeLogo = () => (

    <section className="hero">
        <div className="caption">
            <h3>THE BEST FOOD EXPERIENCE </h3>
            <h4>
                <span className="rsep"></span>
                NOW IN LONDON
				<span className="lsep"></span>
            </h4>

        </div>
    </section>
)