import React from 'react'
import Loader from 'react-loader'
import Widget from '../../core/widget'
import PropTypes from 'prop-types'
import ProgressBar from '../../core/progressbar'
import { SUCCESS_HEADER } from '../../../constants/constants' 
import Confirmation from './confirmation'
import Modal from '../../core/modal'
import { withRouter } from 'react-router-dom'
import { calculateCost } from '../../../utils/utils'
export default class ShippingLabelMaker extends React.PureComponent {

   constructor(props) {
        super(props);
        this.state = {
            shippingDetail: {},
            hasError: true,
            steps:1,
            isModalOpen: false,
        }
        //this.onOpenModal = this.onOpenModal.bind(this)
        this.onChange = this.onChange.bind(this)
        this.onUpdate = this.onUpdate.bind(this)
        this.goForwad =  this.goForwad.bind(this)
        this.goBack = this.goBack.bind(this)
        this.validateForm = this.validateForm.bind(this)
        this.onGetFinalInfo = this.onGetFinalInfo.bind(this)
        this.onOpenModal = this.onOpenModal.bind(this)
        this.onCloseModal = this.onCloseModal.bind(this)
        this.onConfirmOrder = this.onConfirmOrder.bind(this)
  
    }

    componentDidMount() {
        const Ordereditems = JSON.parse(window.localStorage.getItem('items'))
        let temp = this.props.shippingDetail
        temp.productDetails["items"] = Ordereditems
        console.log('temp is',temp)
        this.setState({ shippingDetail: Object.assign({}, temp ) ,steps:this.props.steps })
    }
    onConfirmOrder(){
        this.onOpenModal()
    }
    onUpdate() {
       this.props.actions.setShippingDetail(this.state.shippingDetail)
       this.goForwad()
    }
    onGetFinalInfo(){
        const shippingRate = 2
        const totalCost = calculateCost(this.state.shippingDetail.productDetails, shippingRate)
        this.setState({ shippingDetail: Object.assign({}, this.state.shippingDetail, { totalCost:totalCost } )  } , function(){
             this.props.actions.setShippingDetail(this.state.shippingDetail)
        } )
        this.goForwad()
    }

    goForwad(){
        this.setState({ steps: this.state.steps + 1,hasError: true  } , function(){
             this.props.actions.setSteps(this.state.steps)
        } )
    }
    goBack(){
       this.setState({ steps: this.state.steps - 1,hasError: false  } , function(){
             this.props.actions.setSteps(this.state.steps)
        } )
    }
    onOpenModal() {
        this.setState({ isModalOpen: true})
    }
    onCloseModal() {
        this.setState({ isModalOpen: false })
        this.props.history.push('/');
    }
    validateForm(data) {
        let flag = false;
        for(var key in data ){
            if( (_.isEmpty(data[key]) )){
                flag = true
            }
        }           
       flag ?this.setState({ hasError: true }):this.setState({ hasError: false})
    }
    onChange(event,val) {
        let type,temp ={};
        if(val){
            event = val
        }
       type = event.target.className;
        if (type.includes("receiver")){
            temp = this.state.shippingDetail.receiverDetails
        }
        else if(type.includes("sender")){
            temp = this.state.shippingDetail.senderDetails
        }
        else if(type.includes("product")){
            temp = this.state.shippingDetail.productDetails
        }
        else if(type.includes("shipping")){
            temp = this.state.shippingDetail.productDetails.shippingOption
        }
        const key = event.target.name
        temp[key] = event.target.value
        this.setState({ shippingDetail: Object.assign({},this.state.shippingDetail, temp) })
        this.validateForm(temp)
    }
  
    render() {
        console.log(this.state.shippingDetail)
        return (
              Object.keys(this.state.shippingDetail).length > 0 && (
            <div>             
                <ProgressBar progressSteps={this.state.steps} />
                 <Widget shippingDetail ={ this.state.shippingDetail } hasError ={ this.state.hasError } 
                 steps ={ this.state.steps } onChange = { this.onChange } onUpdate ={ this.onUpdate } goForwad={ this.goForwad } 
                 goBack = { this.goBack } onGetFinalInfo ={ this.onGetFinalInfo } onConfirmOrder = { this.onConfirmOrder } />
                 <Modal header={ SUCCESS_HEADER } isOpen={ this.state.isModalOpen } onClose={ this.onCloseModal }>
                     <Confirmation shippingDetail = { this.state.shippingDetail }/>
                </Modal>
            </div>
        )
        )
    }
}

ShippingLabelMaker.propTypes = {
    actions: PropTypes.object.isRequired,
    shippingDetail: PropTypes.object.isRequired,
}
