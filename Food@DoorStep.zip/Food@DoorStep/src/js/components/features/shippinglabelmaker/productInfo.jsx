import React from 'react'
import PropTypes from 'prop-types'


const ProductInfo = (props) => {
    const {
        productDetails,
        receiverDetails,
        senderDetails,
        totalCost
} = props.shippingDetail
    const { onConfirmOrder, goForwad, goBack, steps } = props


    return (
        <div className='container'>

            <div className='well well-lg table-striped table-bordered table-responsive'>
                <div>
                    <img className='techie-img avatar' src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfb8CAQ7myUK-4Ll4p4j3Y0f7TWjs8eAfpYX3F2xvbNSYjChqC0w" />
                    <div className='container row-block'>
                    <label className='col-md-3'>Product Details:</label>
                        <table className="table table-condensed col-md-6">
                            <thead>
                                <tr>
                                    <th>Product-Name:</th>
                                    <th>Ordered Quanitty:</th>
                                    <th>Price:</th>
                                </tr>
                            </thead>
                            <tbody>
                                {

                                    productDetails.items.map((item) => <Product key={item.id} item={item} />)

                                }
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className='row'>
                    <div className='col-md-12 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Senders Address</label>
                        <div className='col-md-4'>{senderDetails.name + "," + senderDetails.street + "," + senderDetails.city + "," + senderDetails.state}</div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Receiver Address</label>
                        <div className='col-md-4'>{receiverDetails.name + "," + receiverDetails.street + "," + receiverDetails.city + "," + receiverDetails.state}</div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Shipping Option</label>
                        <div className='col-md-4'>Ground:{productDetails.shippingOption.ground} &nbsp; Priority: {productDetails.shippingOption.priority}</div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 row-block'>
                        <label className='col-md-2 col-md-offset-3'>Shipping Cost</label>
                        <div className='col-md-4'>{totalCost}</div>
                    </div>
                </div>

            </div>
            <button type='button' className='btn btn-default' value='cancel' onClick={goBack} disabled={steps === 1}> Previous </button>
            <button type='button' className='btn btn-info' value='save' onClick={onConfirmOrder} >Order Now</button>
            <button type='button' className='btn btn-default' value='cancel' onClick={goForwad} disabled={steps === 4}> Next </button>
        </div>

    )
}

const Product = (props) => {
    let { item_name, item_details, price, orderedQuantity, id } = props.item
    return (

        <tr>
            <td>{item_name}</td>
            <td>{orderedQuantity}</td>
            <td>{price}</td>

        </tr>
    )
}
ProductInfo.propTypes = {
    shippingDetail: PropTypes.object.isRequired,
}
export default ProductInfo
