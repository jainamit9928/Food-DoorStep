import React from 'react'
import { WelcomeLogo  } from '../../core/welcomelogo'
import AlertContainer from 'react-alert'
import { ADDED_TO_CART } from '../../../constants/constants'
import { Menu } from './menudetails'

export default class FoodMenu extends React.PureComponent {

    constructor(props) {
        super(props);
        this.alertOptions = {
            offset: 19,
            position: 'top left',
            theme: 'dark',
            time: 4000,
            transition: 'scale'
        }
        this.showAlert = this.showAlert.bind(this)
        this.onQuantityChange = this.onQuantityChange.bind(this)
    }
    componentDidMount() {
     this.props.actions.getDataRequest();
    }
    
    showAlert()  {
    this.msg.success(ADDED_TO_CART, {
      time: 4000,
      type: 'success'
    })
  }
 
  onQuantityChange(quantityNode){
    const itemId = quantityNode.props.id
    const itemValue = quantityNode.state.value
    console.log(itemValue)
    const item = _.filter(this.props.items, (item) => (item.id === itemId))
    item[0].orderedQuantity= itemValue
    this.props.actions.updatDataRequest(itemId,item[0])
    
  }
    render() {
        console.log("render food menu",this.props.items)
        return (
            <div>
                {
                    this.props.items.length > 0 && (
                        <div>
                        <AlertContainer ref={a => this.msg = a} {...this.alertOptions} />
                        <FoodCart items={this.props.items} showAlert = { this.showAlert } onQuantityChange = { this.onQuantityChange }/>
                        </div>
                        )
                }

            </div>
        )
    }
}

export const FoodCart = (props) => {
    return (
        <div >
            <WelcomeLogo />
            <div className="col-md-1"></div>
            <div className="col-md-10">
            <Menu foodItems={props.items} showAlert = { props.showAlert } onQuantityChange = { props.onQuantityChange }/>
            </div>
           

        </div>
    )
}



