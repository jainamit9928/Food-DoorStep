import React from 'react'
import _ from 'lodash'
import { addToStorage } from '../../../utils/utils'
import NumberInput from 'react-number-input'
import { Link } from 'react-router-dom'

export const Menu = (props) => {
    let { foodItems } = props
    let starters = _.filter(foodItems, (item) => (item.type === "starters"))
    let mainCourse = _.filter(foodItems, (item) => (item.type === "maincourse"))
    let sides = _.filter(foodItems, (item) => (item.type === "sides"))
    let desserts = _.filter(foodItems, (item) => (item.type === "desserts"))

    return (
        <section className="menu">
            <div className="wrapper">
                <div className="menu_title">
                    <h2>Our Menu</h2>
                    
                </div>
                <Link  to={ `/shippingDetail/` }>
                    <input  type='button'  className='btn buyBtn fltRight'  value='BuyNow'/>
               </Link>
                <div className="mean_menu">
                    <Article type="starters" items={ starters } showAlert = { props.showAlert } onQuantityChange = { props.onQuantityChange } />
                    <Article type="mainCourse" items={ mainCourse } showAlert = { props.showAlert } onQuantityChange = { props.onQuantityChange } />
                    <Article type="sides" items={ sides } showAlert = { props.showAlert } onQuantityChange = { props.onQuantityChange } />
                    <Article type="desserts" items={ desserts } showAlert = { props.showAlert } onQuantityChange = { props.onQuantityChange } />

                </div>
                <div className="load-more">
                    <a href="#" id="more_items">
                        show more
					<hr />
                        <span className="bottom_arrow"></span>
                    </a>
                </div>
               
            </div>
        </section>

    )
}
const Article = (props) => {
    
    return (
    <article className="lmenu">
        <h2>{ props.type.toUpperCase() }</h2>
        <ul>
            {_.map(props.items, (itm) => (
                <Item key={itm.id} item={itm} onClick = { () =>{ addToStorage(itm); props.showAlert() } } onQuantityChange = { props.onQuantityChange }/>
            ))
            }
        </ul>
    </article>
)}

const Item = (props) => {
    let quantityNode;
    let { item_name,item_details,price,orderedQuantity,id  } = props.item
    let blockChars= (evt) => {
    if (evt.which < 48 || evt.which > 57)
    {
        evt.preventDefault();
    }
}
    return (
    <li>
        <div className="item_info">
            <h3 className="item_name">{ item_name }</h3>
            <p className="item_desc">{ item_details }</p>
            <h4 className="price"> {"$" + price }</h4>
            <NumberInput ref={a => quantityNode = a} onKeyPress = { blockChars } id ={ id } onChange = { () => props.onQuantityChange(quantityNode) } className ="quantity" value ={ orderedQuantity } name={ id }  type="number"  min={0}  max={5} />
            <button type="button" className="buyBtn btn btn-sm" onClick = { props.onClick } disabled = { ! (orderedQuantity >0) }>AddtoCart</button>
        </div>

    </li>
)}