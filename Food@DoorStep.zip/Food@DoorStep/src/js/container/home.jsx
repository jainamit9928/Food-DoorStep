import { connect } from 'react-redux'
import Home from '../components/home/home'
import { bindActionCreators } from 'redux'
import * as stateActions from '../actions/actions'

 const mapStateToProps = (state, props) => {
         return {
          items:state.foodItems.items,
          isFetching:state.foodItems.isFetching,
          errorMessage:state.foodItems.errorMessage,
        }
  }
 

const mapDispatchToProps = (dispatch) => {
      return {
       actions:bindActionCreators(stateActions, dispatch),
    }
}

const HomeContainer =connect(mapStateToProps, mapDispatchToProps)(Home);
export default HomeContainer
