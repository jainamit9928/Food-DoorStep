import _ from 'lodash'

export const calculateCost = (productDetails, shippingRate) => getPriceTotal(productDetails.items)  * shippingRate * (productDetails.shippingOption.ground === 1 ? 1 : 1.5)
const getPriceTotal = (items) => {
    let sum = 0
    items.map((item) =>{
        sum = sum + (item.price * item.orderedQuantity)
    } )
    console.log("sum is", sum)
    return sum
}

export const addToStorage = (item) => {
    if(item){
        const items = JSON.parse(window.localStorage.getItem('items'))
        items.push(item)
        window.localStorage.setItem('items', JSON.stringify(items))
    }

    else{
        let username = "demoaccount"
        let password =  "Passw0rd"
        let items = []
        let status =""
        window.localStorage.setItem('username', JSON.stringify(username))
         window.localStorage.setItem('password', JSON.stringify(password))
         window.localStorage.setItem('items', JSON.stringify(items))
         window.localStorage.setItem('status', JSON.stringify(status))
    }
        
    }
