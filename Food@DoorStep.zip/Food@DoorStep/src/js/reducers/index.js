import { combineReducers } from 'redux'
import { shippingDetail, foodItems } from './reducer'

const shippingLabelMakerReducer = combineReducers({
  shippingDetail,
  foodItems,
})

export default shippingLabelMakerReducer
