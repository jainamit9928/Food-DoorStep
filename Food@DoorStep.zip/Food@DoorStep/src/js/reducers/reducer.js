import * as actionTypes from '../constants/constants.js'


export const shippingDetail=(state = { steps:1 , detail:{ receiverDetails:{name:"", street:"", city:"", state:"" }, senderDetails:{ name:"", street:"", city:"", state:"" }, productDetails:{items:[] ,shippingOption:{ ground:1, priority:2 }}, totalCost:null } }, action) => {
    switch (action.type) {

        case actionTypes.SET_DATA:
            return Object.assign({}, state, {
                detail:action.data
            }
            );
        case actionTypes.SET_STEPS:
            return Object.assign({}, state, {
              steps:action.data
            })

        default:
            return state;
    }
}

export const foodItems = (state = { items: [], isFetching: false, errorMessage: '' }, action) => {
    switch (action.type) {

        case actionTypes.GET_DATA_REQUEST:
            return Object.assign({}, state, {
                isFetching: true,
            }
            );

        case actionTypes.GET_DATA_SUCCESS:
            return Object.assign({}, state, {
                isFetching: false,
                items: action.data,
            }
            );

        case actionTypes.GET_DATA_FAILURE:
            return Object.assign({}, state, {
                isFetching: false,
                errorMessage: action.message,
            })

            case actionTypes.UPDATE_DATA_REQUEST:
            return Object.assign({}, state, {
                isFetching: true,
            }
            )

        case actionTypes.UPDATE_DATA_SUCCESS:
            return Object.assign({}, state, {
                isFetching: false
            }
            )

        case actionTypes.UPDATE_DATA_FAILURE:
            return Object.assign({}, state, {
                isFetching: false,
                errorMessage: action.message,
            })


        default:
            return state;
    }
}

