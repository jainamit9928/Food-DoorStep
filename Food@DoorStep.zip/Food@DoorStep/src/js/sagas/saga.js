import { call, put, takeEvery, all, take, race, select } from 'redux-saga/effects'
import 'regenerator-runtime/runtime'
import _ from 'lodash'
import * as actionTypes from '../constants/constants.js'
import { getData, updateData } from '../apis/api'
import * as actions from '../actions/actions'
import { addToStorage } from '../utils/utils'

//backgroundTask
export function* watchAndLog() {
  while (true) {
    yield take('*')
    yield select()
  }
}

export function* watchStartBackgroundTask() {
  const status = JSON.parse(window.localStorage.getItem('status'))
  if ( !(status == "login successfully") )  {
    addToStorage()
  }

  while (true) {
    yield take('*')
    yield race({
      task: call(watchAndLog),
      cancel: take('CANCEL_TASK'),
    })
  }
}
export function* fetchData() {
  try {
    const data = yield call(getData)
    yield put(actions.getDataSuccess(data))
  } catch (error) {
    yield put(actions.getDataFailure(error.message))
  }

}

export function* updateFilteredData(action){
  try {
    const res = yield call(updateData, action.id, action.updatedObj)
    if(res){
       yield put(actions.updateDataSuccess(res.data))
    }
  } catch (error) {
    yield put(actions.updatDataFailure(error.message))
  }
}

export function* watchFetchAsync() {
  yield takeEvery(actionTypes.GET_DATA_REQUEST, fetchData)
  yield takeEvery(actionTypes.UPDATE_DATA_REQUEST, updateFilteredData)
}


export function* rootSaga() {
  yield all([watchFetchAsync(), watchStartBackgroundTask()])
}